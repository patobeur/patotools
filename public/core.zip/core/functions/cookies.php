<?php
	//!ROOTS['distant'] && !empty($_COOKIE['barrecode']) ? print_air($_COOKIE['barrecode'],'cookie') : ''; //! Cookie -> todo in User Class
	
	// if (isset($_COOKIE['barrecode'])) {
  	//	print_air($_COOKIE,"_COOKIE");
	// }
		function clean_url($url) {
			return parse_url($url);
		}
		if (!empty($_SERVER['HTTP_REFERER'])) {
			$url = clean_url($_SERVER['HTTP_REFERER']);
			$_SESSION['first'] = true;
		}
		else {
			$_SESSION['first'] = false;
		}
?>