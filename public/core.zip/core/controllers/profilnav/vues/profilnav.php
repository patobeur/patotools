<li><a href="#HREF#" title="#TITLE#" class="navlink">#AWESOME#</a></li>AAAAAAAAAAAAAAAAAA
