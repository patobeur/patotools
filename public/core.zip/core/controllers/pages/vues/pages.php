<div class="listeactions">
	<div class="formulaireaction">
		<div class="form-page">
			<div class="formulaire">
				<img title="PAT BARRECODE" alt="logo et lien vers la page accueil" src="theme/img/logo.png"><br/>
				<h3>Bientôt ici, une gestionnaire de pages !</h3>
				<p>Plusieurs fonctionalités en cours d'élaboration</p>
				<ol>
					<li>affichage de message sur la vie de l'etablissement</li>
					<li>des post-it échangés par les utilisateurs de l'app</li>
					<li>des post-it pour rappel au étudiants</li>
				</ol>
				#CONTENTS#
			</div>
		</div>
	</div>
</div>