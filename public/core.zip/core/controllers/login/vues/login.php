<div class="listeactions">
	#CONTENT_LOGIN#
</div>