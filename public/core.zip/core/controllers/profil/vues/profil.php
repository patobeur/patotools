<div class="listeactions">
	<div class="formulaireaction">
		<div class="form-page">
			<div class="formulaire">
				<img title="PAT BARRECODE" alt="logo et lien vers la page accueil" src="theme/img/logo.png"><br/>
				<h3>Bientôt ici, votre page de profil !</h3>
				<p>Plusieurs fonctionalités en cours d'élaboration</p>
				<ol>
					<li>un formulaire de modification de vos données (en fonctions de vos droits)</li>
					<li>un formulaire de modification de vos paramètres (en fonctions de vos droits)</li>
				</ol>
				#CONTENTS#
			</div>
		</div>
	</div>
</div>