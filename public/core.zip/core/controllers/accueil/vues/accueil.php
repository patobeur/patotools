<div class="formulaireaction">
	<div class="form-page login">
		<br/><br/><br/><br/><br/>
		<img title="PAT BARRECODE" alt="logo et lien vers la page accueil" src="theme/img/logo.png"><br/>
		
		#CONTENTS#
	</div>
</div>