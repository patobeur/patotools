<div class="navactions">
		#CONTENTS#		
</div>
<div class="listeactions">
	<div class="formulaireaction">
		#ACTIONS#	
	</div>	
</div>