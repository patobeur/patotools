<div class="form-page">
    <form class="formulaire#CSSALERT#" method="post" action="#ACTIONFORM#" id="finish">
		<h2>(<i class="fas fa-user"></i> <i class="fas fa-barcode"></i>) <i class="fas fa-plus"></i> (<i class="fas fa-laptop"></i> <i class="fas fa-barcode"></i>) <i class="fas fa-equals"></i> <i class="fas fa-laptop"></i> <i class="far fa-calendar-plus"></i></h2>
		<h2>#TITREACTIONS#</h2>
		#INPUT_USER#
		#INPUT_ARTICLE#
        <div class="ligne submit" title="Envoyer le formulaire !" >
            <button>submit</button>
            <i class="far fa-check-circle"></i>
        </div>
        <input type="hidden" id="actiontype" name="action" value="#ACTIONTYPE#">
    </form>
</div>
#MESSAGE#