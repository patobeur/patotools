<div class="aide-help">
    #MESSAGE#
</div>