
<div class="form-page">
	<div class="message testdev1">
		<form class="#CSSCLASSNAME#" method="post" action="#ACTIONFORM#">
		<h2>#TITRE#</h2>
		<div>
			#INPUTSLIST#
		</div>
		<div class="coment submit" title="Envoyez votre commentaire !" >
			<input type="hidden" id="actiontype" name="action" value="#HIDDENACTIONTYPE#">
			<input type="hidden" id="#GROUPENAME#" name="#GROUPENAME#" value="#HIDDENACTION#">
			<button>#SUBMITCONTENT#</button>
			<i class="far fa-check-circle"></i>
			<!-- <i class="fas fa-check-circle"></i> -->
		</div>
	</form>
	</div>
</div>