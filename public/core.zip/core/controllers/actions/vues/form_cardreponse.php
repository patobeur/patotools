<div class="form-page">
    <div class="message card good">
        <div class="image"><i class="fas fa-user"></i></div>
        <div> #NOM#
        </div>
    </div>
</div>