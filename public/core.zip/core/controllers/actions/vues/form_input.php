						<div title="#TITLEINPUT#" class="ligne">
							<i class="fas fa-barcode"></i> <i class="fas deuz fa-#AWESOMEINPUT#"></i>
							<input type="text" id="codebarre_item" class="shadows" name="#INPUTNAME#" placeholder="#PLACEHOLDER#" value="##ITEM##"
							onfocus="this.placeholder = ''"
							onblur="this.placeholder = '#PLACEHOLDER#'"#AUTOFOCUS#>
						</div>
