<div class="formulaireaction">
	<div class="form-page login">
		<br/><br/><br/><br/><br/>#CONTENTS#
	</div>
</div>