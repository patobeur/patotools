            <div class="listeactions">
                <div class="formulaireaction">
                    <div class="form-page login">
                        <form class="formulaire" action="" method="post" id="finish">
                            <!-- <img class="center" src="theme/img/logo.png"> -->
                            <h2>Connectez-vous !</h2>
                            <div title="Votre identifiant : E-Mail !" class="ligne">
                                <i class="fas fa-at"></i>
                                <input type="text" id="login" class="email shadows" name="login" placeholder="E-Mail" value="#VALUE_LOGIN#"
                                onfocus="this.placeholder = ''"
                                onblur="this.placeholder = 'E-Mail'">
                            </div>
                            <div title="Votre Authentifiant: Mot de Passe !" class="ligne">
                                <i class="fas fa-key"></i>
                                <input type="password" id="password" class="word shadows" name="password" placeholder="Mot de Passe"  value="#VALUE_PASSWORD#" 
                                onfocus="this.placeholder = ''"
                                onblur="this.placeholder = 'Mot de Passe'">
                            </div>
                            <!-- <div id="login" class="cliquable-btn"></div> -->
                            <div class="ligne submit" title="Connectez-vous !" >
                                <button>submit</button>
                                <i class="fas fa-seedling"></i>
                            </div>
                            <!-- <hr>
                            <div id="ninfo"></div>
                            <div id="readyState"></div>
                            <div id="status"></div> -->
                        </form>
                    </div>
                </div>
            </div>