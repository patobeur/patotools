<div class="listeactions">
	<div class="pagesize">
		<div class="pagesection">
			<div class="section">
					<!-- <img title="PAT BARRECODE" alt="logo et lien vers la page accueil" src="theme/img/logo.png"><br/> -->
					<div class="importnav">
						<ul class="import">
							#NAVITEMS#
						</ul>
					</div>
					<div id="filterform" class="filterform">
						#FILTERFORM#
					</div>

					#CONTENTS#
			</div>
		</div>
	</div>
	<div class="sectionfooter">...</div>
</div>