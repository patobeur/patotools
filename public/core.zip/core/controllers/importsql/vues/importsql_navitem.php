		<li class="navitem">
			<a href="#ITEMURL#" title="#ITEMTITLE#">#ITEM#</a>
		</li>
