	<li class="navitem">
		#DBNAME#
		<ul class="navitems">
			#ITEMS#
		</ul>
	</li>
